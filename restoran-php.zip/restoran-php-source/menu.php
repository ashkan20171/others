 <ul class="topmenu">
  <li><a href="index.php">صفحه اصلي</a></li>
  <li><a href="menughaza.php">منوی غذا</a></li>
  <li><a href="sefareshh.php">سفارش غذا</a></li>
  <li><a href="galery.php">گالری تصاویر</a></li>
  <li><a href="tamasbama.php">تماس با ما</a></li>
    <li><a href="nazarsanji.php">نطر سنجی</a></li>
     <li><a href="log.php">ورود مدیر</a></li>
 </ul>