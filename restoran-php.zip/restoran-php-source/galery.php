<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>برنامه جامع رستوران</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
body {
	background-color: #CFC;
}
</style>
</head>
<body>
<div class="container">
 <?php require "header.php" ?>
 <?php require "menu.php" ?>
 <div class="content">
 <table width="500" border="8" align="center" cellpadding="5" cellspacing="5">
  <tr>
    <td><p><img src="pic/kabab.jpg" width="200" height="200" /></p>
      <h4>چلو کباب</h4></td>
    <td><p><img src="pic/morgh.JPG" width="200" height="200" /></p>
      <h4>چلو مرغ</h4></td>
  </tr>
  <tr>
    <td><p><img src="pic/سالاد.jpeg" width="200" height="200" /></p>
      <h4>سالاد</h4></td>
    <td><p><img src="pic/سبزی.jpeg" width="200" height="200" /></p>
      <h4>خورشت قورمه سبزی</h4></td>
  </tr>
  <tr>
    <td><p><img src="pic/لاهئث.jpeg" width="200" height="200" /></p>
      <h4>خورشت قیمه</h4></td>
    <td><p><img src="pic/نوشابه.jpeg" width="200" height="200" /></p>
      <h4>نوشابه</h4></td>
  </tr>
  <tr>
    <td><p><img src="pic/55.jpg" width="200" height="200" /></p>
      <h4>چلو گوشت</h4></td>
    <td><p><img src="pic/44.jpg" width="200" height="200" /></p>
      <h4>چلو گوشت</h4></td>
  </tr>
  <tr>
    <td><p><img src="pic/3.jpg" width="200" height="200" /></p>
      <h4>چلو مرغ</h4></td>
    <td><p><img src="pic/2.jpg" width="200" height="200" /></p>
      <h4>چلو کباب</h4></td>
  </tr>
  <tr>
    <td><p><img src="pic/44.jpg" width="200" height="200" /></p>
      <h4>چلو گوشت</h4></td>
    <td><p><img src="pic/4.jpg" width="200" height="200" /></p>
      <h4>چلو گوشت</h4></td>
  </tr>
  <tr>
    <td colspan="2"><p><img src="pic/untitled1.jpg" width="200" height="200" align="middle" class="err" /></p>
      <h4>چلو ماهی</h4></td>
  </tr>
  </table>

 </div>

</div>
</body>
</html>