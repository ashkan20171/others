<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>برنامه جامع رستوران</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
body {
	background-color: #CFC;
}
</style>
</head>
<body>
<div class="container">
 <?php require "header.php" ?>
 <?php require "menu.php" ?>
 <div class="content" dir="ltr">
   <table width="500" align="center" cellpadding="5" cellspacing="5" dir="rtl" class="tblhead">
     <tr class="err">
       <th align="right" bgcolor="#CCCCCC"><strong>تصویر غذا یا دسر</strong></th>
       <th align="center" bgcolor="#CCCCCC"><strong>نام غذا یا دسر</strong></th>
       <th align="center" bgcolor="#CCCCCC">قیمت</th>
       <th align="center" bgcolor="#CCCCCC"><strong>توضیحات</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/kabab.jpg" width="100" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>چلوکباب کوبیده</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">25000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>ایرانی</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/morgh.JPG" width="100" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>چلو مرغ</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">25000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>ایرانی</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/44.jpg" width="100" height="100" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>جلو گوشت</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">30000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>گوشت گوساله</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/untitled1.jpg" width="100" height="100" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>چلوماهی</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">25000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>ماهی قزل آلا</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/سبزی.jpeg" width="100" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>خورشت قورمه سبزی</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">20000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>ایرانی</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/لاهئث.jpeg" width="100" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>خورشت قیمه</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">20000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>ایرانی</strong></th>
     </tr>
     <tr>
       <th align="right" bgcolor="#CCCCCC"><img src="pic/نوشابه.jpeg" width="70" height="70" /><img src="pic/سالاد.jpeg" width="70" height="70" /></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>سالاد،نوشابه،دوغ،ماست،سس</strong></th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead">10000 ریال</th>
       <th align="center" bgcolor="#CCCCCC" class="tblhead"><strong>سالاد فصل و دوغ تازه</strong></th>
     </tr>
   </table>
 </div>
</div>
</body>
</html>